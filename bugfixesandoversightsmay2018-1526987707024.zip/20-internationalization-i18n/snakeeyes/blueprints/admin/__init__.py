from snakeeyes.blueprints.admin.views import admin
