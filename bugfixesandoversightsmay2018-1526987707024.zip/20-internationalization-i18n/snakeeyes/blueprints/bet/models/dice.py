import random


def roll():
    """
    Randomly roll a dice.

    :return: int
    """
    return random.randint(1, 6)
